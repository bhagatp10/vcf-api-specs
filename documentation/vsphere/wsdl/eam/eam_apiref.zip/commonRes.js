var ID_Copyright = "&copy; 2011-2024 Broadcom. All Rights Reserved. " +
   "The term \"Broadcom\" refers to Broadcom Inc. and/or its subsidiaries.";
var ID_VersionInformation = "Revision 2023 &nbsp; | &nbsp; vSphere ESX Agent Manager API &nbsp;  | &nbsp;  Version 8.0";
